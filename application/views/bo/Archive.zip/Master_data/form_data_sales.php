<!-- ============================================================== -->
<!-- Start right Content here -->
<!-- ============================================================== -->                      
<div class="content-page">
	<!-- Start content -->
	<div class="content">
		<div class="container">

			<!-- Page-Title -->
			<div class="row">
				<div class="col-sm-12">
					<h4 class="pull-left page-title"><?=$title?></h4>
					<ol class="breadcrumb pull-right">
						<li><a href="<?=base_url()?>"><?=$site->title?></a></li>
						<li class="active"><?=$title?></li>
					</ol>
				</div>
			</div>
			
			<div class="row">
				<div class="col-md-12">
					<div class="panel panel-default">
						<div class="panel-heading">
							<!--<h3 class="panel-title">Header</h3>-->
						</div>
						<div class="panel-body">
							<?php isset($_GET['trx'])?$update='?trx='.$_GET['trx']:$update=null; ?>
							<?=form_open($this->control.'/'.$page.$update, array('class'=>"cmxform form-horizontal tasi-form"))?>
							<?= isset($_GET['trx'])?'<input type="hidden" name="update" value="1" />':''; ?>
								
								<div class="form-group " style="margin-bottom:5px;">
									<label class="control-label col-lg-2">Nama</label>
									<div class="col-lg-10">
										<?php $field = 'Nama'; ?>
										<input class="form-control" type="text" name="<?=$field?>" value="<?=set_value($field)?set_value($field):(isset($master_data[$field])?$master_data[$field]:null)?>" required aria-required="true" />	
										<?=form_error($field, '<div class="error" style="color:red;">', '</div>')?>
									</div>
								</div>

								<div class="form-group " style="margin-bottom:5px;">
									<label class="control-label col-lg-2">Status</label>
									<div class="col-lg-10 form-inline">
										<?php $field = 'status'; ?>
										<div class="radio radio-primary">
											<input class="form-control" type="radio" id="<?=$field?>1" name="<?=$field?>" value="1" <?=($master_data[$field]=='1')?'checked':(isset($_GET['trx'])?null:'checked')?> required />
											<label for="<?=$field?>1"> Aktif </label>
										</div>
										<div class="radio radio-primary">
											<input class="form-control" type="radio" id="<?=$field?>0" name="<?=$field?>" value="0" <?=($master_data[$field]=='0')?'checked':null?> required />
											<label for="<?=$field?>0"> Tidak Aktif </label>
										</div>
										<?=form_error($field, '<div class="error" style="color:red;">', '</div>')?>
									</div>
								</div>
								
								<div class="form-group">
									<div class="col-lg-offset-2 col-lg-10">
										<button class="btn btn-primary waves-effect waves-light" type="submit" name="save" id="save" ><i class="fa fa-save"></i> Save</button>
									</div>
								</div>
								
							<?=form_close()?>
						</div>
					</div>
				</div>
				
			</div> <!-- End Row -->
			
		</div> <!-- container -->
				   
	</div> <!-- content -->

</div>
<!-- ============================================================== -->
<!-- End Right content here -->
<!-- ============================================================== -->

<script>
function upperCaseF(a){
    setTimeout(function(){
        a.value = a.value.toUpperCase();
    }, 1);
}
</script>
